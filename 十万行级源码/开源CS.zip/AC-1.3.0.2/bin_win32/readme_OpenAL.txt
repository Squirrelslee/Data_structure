AssaultCube uses the official OpenAL implementation by default.
If you encounter any sound problems you can switch to OpenAL-Soft, 
this can be done by renaming openal32_RemoveThisPartToUseOpenAL-Soft.dll
to openal32.dll

OpenAL-Soft is an OpenAL implementation licensed under the terms of the LGPL.
Visit http://kcat.strangesoft.net/openal.html

