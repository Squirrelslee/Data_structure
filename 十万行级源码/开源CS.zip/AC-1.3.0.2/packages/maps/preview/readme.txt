Place preview pictures of your custom maps into this directory.
Requirements:
 * The image size must be a maximum of 200x150 pixels.
 * It must be in JPEG format (with a lower-case ".jpg" extension).

Do NOT use preview pictures, if you're already low on graphics memory.
You can disable them by using the command "hidebigmenuimages 1".
